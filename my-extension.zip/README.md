# Cards Bookmark Homepage

Forked and modified from https://github.com/Kieran-Edwards/basic-bookmark-homepage

Thanks to this person.

# Develop

### Building styles: 
```
sass scss/style.scss styles/master.css
```

### Watching Styles:
```
sass --watch scss/style.scss:styles/master.css
```
###### SCSS files are not imported to Extension distributor
